package employee;

public class EmployeeDetails {
		private String FirstName, MiddleName, LastName, Name, Title;
		private String EmployeeNumber;
		
		public EmployeeDetails(String EmployeeNumber, String FirstName, String MiddleName, String LastName, String Name, String Title) {
			this.EmployeeNumber = EmployeeNumber;
			this.FirstName= FirstName;
			this.MiddleName = MiddleName;
			this.LastName = LastName;
			this.Name = Name;
			this.Title = Title;
		}

		public String getFirstName() {
			return FirstName;
		}

		public void setFirstName(String FirstName) {
			this.FirstName = FirstName;
		}
		
		public String getMiddleName() {
			return MiddleName;
		}

		public void setMiddleName(String MiddleName) {
			this.MiddleName = MiddleName;
		}

		public String getLastName() {
			return LastName;
		}

		public void setLastName(String LastName) {
			this.LastName = LastName;
		}

		public String getName() {
			return Name;
		}

		public void setName(String Name) {
			this.Name = Name;
		}

		public String getTitle() {
			return Title;
		}

		public void setTitle(String Title) {
			this.Title =Title;
		}

		public String getEmployeeNumber() {
			return EmployeeNumber;
		}

		public void setEmployeeNumber(String EmployeeNumber) {
			this.EmployeeNumber = EmployeeNumber;
		}
		
		
}

