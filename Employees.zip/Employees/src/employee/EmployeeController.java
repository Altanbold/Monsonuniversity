package employee;

import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;

import javafx.application.Platform;
import javafx.beans.property.StringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

public class EmployeeController implements Initializable {

    @FXML
    private TableView<EmployeeDetails> dgvEmployees;

    @FXML
    private TableColumn<EmployeeDetails, StringProperty> eID;

    @FXML
    private TableColumn<EmployeeDetails, StringProperty> fName;

    @FXML
    private TableColumn<EmployeeDetails, StringProperty> mName;

    @FXML
    private TableColumn<EmployeeDetails, StringProperty> lName;

    @FXML
    private TableColumn<EmployeeDetails, StringProperty> nName;

    @FXML
    private TableColumn<EmployeeDetails, StringProperty> tTitle;

    @FXML
    private Button btnClose;

    @FXML
    void Close(ActionEvent event) {
    		Platform.exit();
    }


    ObservableList <EmployeeDetails> oblist = FXCollections.observableArrayList();

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		
		try {
			Connection con = DBHandling.getConnection();
			ResultSet rs = con.createStatement().executeQuery("select * from emloyees");
			while(rs.next()) {
				oblist.add(new EmployeeDetails(
						rs.getString("EmployeeNumber"),
						rs.getString("FirstName"),
						rs.getString("MiddleName"),
						rs.getString("LastName"),
						rs.getString("Name"),
						rs.getString("Title")));
			}
		} catch (SQLException ex) {
						Logger.getLogger(EmployeeController.class.getName()).log(Level.SEVERE, null, ex);
		}
	
		eID.setCellValueFactory(new PropertyValueFactory<>("EmployeeNumber"));
    	fName.setCellValueFactory(new PropertyValueFactory<>("FirstName"));
    	mName.setCellValueFactory(new PropertyValueFactory<>("MiddleName"));
    	lName.setCellValueFactory(new PropertyValueFactory<>("LastName"));
    	nName.setCellValueFactory(new PropertyValueFactory<>("Name"));
    	tTitle.setCellValueFactory(new PropertyValueFactory<>("Title"));
    	
    	dgvEmployees.setItems(oblist);
		
	}

}
